@extends('layouts.app')

@section('content')
<div class="container-fluid between" style="width:77%; height:77%">
        
        
            
            
            
                <div class="row justify-content-center "  >
                    <div class="col-5 ">
                        <div class="col-12 col-sm-12 col-md-12 col-xl-12 " style="margin-top:5%">
                            <div class="card-header bg-dark border-success" style="margin-bottom: 5%">
                                <h2 class="title text-white card bg-dark py-2" style="text-align:center">{{ $producto->nombre_producto }}</h2>
                            </div>
                                <figure class="img-fluid">
                                    <img src="{{ asset('images/' . $producto->imgProducto) }}" class="rounded img-fluid  bg-dark" width="100%" alt="Ai Shite Night ">
                                </figure>
                            <div class="card-header bg-dark border-success " style="margin-bottom: 5%">
                                                   
                                <h2 class="text-white" style="text-align:center">S/ {{ $producto->precio}}</h2>
                                
                            </div>   
                        </div>
                    </div>
                
                    <div class="col-5 card row justify-content-center" style="margin-top: 19%; margin-bottom: 10%">
                        <div class="justify-content-center pt-3">
                            
                            
                            <div class="col-8" style="text-align:center; margin: auto">
                                <h4>Ingrese su tarjeta de crédito</h4>
                            </div>
                            
                                <input type="text" class="form-control col-2 bg-white" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">
                                <input type="text" class="form-control col-2 bg-white" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">
                                <input type="text" class="form-control col-2 bg-white" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">
                                <input type="text" class="form-control col-2 bg-white offset-md-1" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">
                                <br>
                                <br>
                                    <h3>Ingrese sus nombres y apellidos</h3> 
                                    <input class="comp" style="text-align:center; width:100%" placeholder="Nombres y apellidos"><br>
                                    <h3>Ingrese la fecha de expiracion de su tarjeta</h3>
                                    <input class="comp" style="text-align:center; width:100%" placeholder="Fecha de expiracion"><br>
                                    <h3>Ingrese el codigo de seguriad</h3>
                                    <input class="comp" style="text-align:center; width:100%" placeholder="Codigo de seguridad"><br>
                                    
                                    <h3>DNI</h3> <input style="text-align:center; width:100%" placeholder="NUmero de DNI"><br>
                                    <br>
                                
                            <div class="row justify-content-center">
                            <a href="" class="btn btn-success ">
                                Comprar
                            </a>
                            </div>
                        </div>
                    </div>
                </div>
            
            
        
        
</div>
@endsection
