@extends('layouts.app')

@section('content')

<div class="container-fluid x " >
<div class="row" >
    <div class="col-1 col-sm-1 col-md-1 col-xl-1"></div>
    <div class="col-10 col-sm-10 col-md-10 col-xl-10" >
        <div class="row" >
            <div class="col-12 col-sm-12 col-md-5 col-xl-4 bordec" style="margin-top:3%">    
                <img src="/images/0d66d97c1c5655ffa45256998c304e54.jpg" alt="" class="imga">
                <hr />
        
                <ul class="list-unstyled">
                    <li>
                        <a href="/directorio?genero=accion" class="dropdown-item textu colorru">
                        <span class="mif-user mif-1x pr-2" > </span>Información
                        </a>
                    </li>
                    <li>
                        <a href="{{ action('UserController@edit', Auth::id()) }}" class="dropdown-item textu colorru">
                        <span class="mif-pencil mif-1x pr-2" > </span>Editar Perfil
                        </a>
                    </li>
                    <li>
                        <a href="{{ action('UserController@edit', Auth::id()) }}" class="dropdown-item textu colorru">
                        <span class="{{ action('UserController@eliminarPerfil', Auth::id()) }}" > </span>Eliminar Perfil
                        </a>
                    </li>
                    <li>
                        <a href="/directorio?genero=accion" class="dropdown-item textu colorru">
                        <span class="mif-clipboard mif-1x pr-2" > </span>Historial de compras
                        </a>
                    </li>
                    <li>
                        <a href="/directorio?genero=accion" class="dropdown-item textu colorru">
                        <span class="mif-plus mif-1x pr-2" > </span>Pedidos
                        </a>
                    </li>
                    <li>
                        <a href="/directorio?genero=accion" class="dropdown-item textos colorra">
                        <span class="mif-exit mif-1x pr-2" > </span>Salir
                        </a>
                    </li>
                    
                </ul>   
            </div>
        <div class="col-12 col-sm-12 col-md-7 col-xl-8 bordec" style="margin-top:3%">
            <div class="row">
                <div class="col-1"></div>
                <div class="col-7 col-sm-7 col-md-4 col-xl-4">
                    <h2 class="mt-4 mb-4 tamañot">Perfil</h2>
                    <hr />
                        
                        <h3 class="tamaños">Nombres</h3>
                        <p class="tamañoc">{{ $user->name }}</p>
                        <h3 class="tamaños">Apellidos</h3>
                        <p class="tamañoc">{{ $user->apellidos }}</p>
                        <h3 class="tamaños">Fecha de nacimiento</h3>
                        <p class="tamañoc">{{ $user->fecha_nacimiento }}</p>
                        <h3 class="tamaños">Email</h3>
                        <p class="tamañoc">{{ $user->email }}</p>
                        <h3 class="tamaños">Domicilio</h3>
                        <p class="tamañoc">--------------------</p>
                </div>
                <div class="col-7 col-sm-7 col-md-6 col-xl-6">
                <h2 class="titulo  pt-5 mb-4  tamañot"> <span class="mif-favorite  mif-1x pr-2" style="color: Red;"> </span>Lista de mangas favoritos</h2>
                
                                        <div class="caja-scroll caja1">
                                            <ul class="categories list-unstyled">
                                                <li>
                                                    <a href="/directorio?genero=accion" class="dropdown-item tamaños colorh">
                                                     Naruto
                                                    </a>
                                                </li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>
                                                <li><a href="/directorio?genero=artes-marciales" class="dropdown-item tamaños colorh">Naruto</a></li>

                                            </ul>
                                        </div>
                </div>
            </div>
        </div>
        </div>
</div>
    <div class="col-1 col-sm-1 col-md-1 col-xl-1"></div>
</div>
</div>

@endsection

